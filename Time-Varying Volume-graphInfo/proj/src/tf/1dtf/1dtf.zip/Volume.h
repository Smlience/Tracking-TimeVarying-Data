#ifndef VOLUME_H
#define VOLUME_H

#include "util/Vector3.h"
#include "dm/VolumeMeta.h"

class Volume 
{

public:
	Volume();
	~Volume();
	// clear volume data
	void clear();

	bool loadVolume(const char* filename);
	bool loaded();

	const char* getFileName() const {return m_pFileName;}

	inline Vector3i getAlignedDim() const { return m_alignedDim; }
	inline Vector3f getNormalizedDim() const { return m_normalizedDim; }
	// Slices number
	inline Vector3i getDimension() const { return meta.dim; }
	inline Vector3f getSpacing() const { return meta.spacing; }

	/**
	 * @brief Deprecated. Use data<DataType>() instead.
	 * @date 2013/06/14
	 */
	unsigned char* getVolume() const {
		return data<unsigned char>();
	}

	template<typename T>
	T* data() const
	{
		return static_cast<T*>(meta.data);
	};

	inline void setDimension(Vector3i dim)
	{
		meta.dim = dim;
	}

	inline void setData(void* d)
	{
		meta.data = d;
	};

protected:
	// get the power of 2 greater than or equal to size
	int getPow2(int size);

	// trilinear interpolation
	double intpTrilinear(unsigned char* pData, double x, double y, double z);

	// trilinear cubic bspline scalar interpolation
	double cubicIntpValue(double v0, double v1, double v2, double v3, double mu);
	double triCubicIntpValue(unsigned char* pData, double x, double y, double z);

	// nearest neighbor scalar value
	double getValue(unsigned char* pData, double x, double y, double z);

private:
	const char* m_pFileName;
	VolumeMeta meta;
	Vector3i m_alignedDim; // xSize
	Vector3f m_normalizedDim; // xfSize the spacings of each dimension
};

#endif // VOLUME_H
